# VirtualRAM Pro for Windows 11 — Portable Edition

## Start the app
1. Extract the ZIP to a folder (for example, `Desktop\VirtualRAM Pro`).
2. Double-click **Start VirtualRAM Pro.cmd**.
3. The launcher starts a local-only web server and opens VirtualRAM Pro in an app-style Edge/Chrome window.
4. Close the app window to stop the local server. If needed, run **Stop VirtualRAM Pro.cmd**.

No administrator rights, installer, or internet connection is required for normal use. Windows PowerShell and Microsoft Edge or Google Chrome are required. If neither browser is found, the launcher opens your default browser.

## What this download is
This is a portable Windows app-style package around the VirtualRAM Pro HTML dashboard. It is **not** a compiled native `.exe` or signed `.msi/.msix` installer. The separate native C# WPF source is included in the full developer project, but could not be compiled here because the .NET SDK / Windows build tools are not installed in this build environment.

## Data and privacy
- The dashboard is served only from `127.0.0.1` (this PC); it is not exposed to your network.
- The app uses browser-exposed information only. Some Windows metrics such as total physical RAM, per-process usage, GPU load, Windows Defender status and firewall configuration require the native Windows edition and are not available to this browser package.
- Do not treat browser-only security checks as an antivirus scan. Use Windows Security / Microsoft Defender for malware scanning.
- Saved preferences are stored in the dedicated browser profile under `%LOCALAPPDATA%\VirtualRAMPro\BrowserProfile`.

## Sharing
You can share this ZIP with another Windows 11 user. They extract it and run `Start VirtualRAM Pro.cmd`. Windows SmartScreen or antivirus may show a warning for downloaded script files; only run it if you trust the source and have inspected the scripts. The scripts are included in plain text for review.

## Uninstall
Close VirtualRAM Pro, delete the extracted folder, and optionally delete `%LOCALAPPDATA%\VirtualRAMPro` to remove the app's local browser profile and state.
