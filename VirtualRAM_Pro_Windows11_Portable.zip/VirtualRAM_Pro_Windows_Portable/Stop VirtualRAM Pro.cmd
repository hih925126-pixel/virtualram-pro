@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$d=Join-Path $env:LOCALAPPDATA 'VirtualRAMPro'; if(Test-Path (Join-Path $d 'server.pid')){$p=[int](Get-Content (Join-Path $d 'server.pid') -Raw); Stop-Process -Id $p -Force -ErrorAction SilentlyContinue}; Remove-Item (Join-Path $d 'server.pid'),(Join-Path $d 'server.port') -Force -ErrorAction SilentlyContinue"
echo VirtualRAM Pro local server stopped.
pause
