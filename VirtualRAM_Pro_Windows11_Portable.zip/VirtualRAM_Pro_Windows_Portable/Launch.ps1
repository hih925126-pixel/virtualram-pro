$ErrorActionPreference = "Stop"
$stateDir = Join-Path $env:LOCALAPPDATA "VirtualRAMPro"
New-Item -ItemType Directory -Force -Path $stateDir | Out-Null

# If a previous instance is running, reuse its local server.
$port = $null
$pidFile = Join-Path $stateDir "server.pid"
$portFile = Join-Path $stateDir "server.port"
if ((Test-Path $pidFile) -and (Test-Path $portFile)) {
  try {
    $oldPid = [int](Get-Content $pidFile -Raw)
    $oldPort = [int](Get-Content $portFile -Raw)
    $p = Get-Process -Id $oldPid -ErrorAction Stop
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$oldPort/" -UseBasicParsing -TimeoutSec 2
    if ($r.StatusCode -eq 200) { $port = $oldPort }
  } catch {}
}
$serverProcess = $null
if (-not $port) {
  $tcp = New-Object System.Net.Sockets.TcpListener([Net.IPAddress]::Loopback,0)
  $tcp.Start()
  $port = ([Net.IPEndPoint]$tcp.LocalEndpoint).Port
  $tcp.Stop()
  $serverProcess = Start-Process -FilePath "powershell.exe" -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-WindowStyle","Hidden",
    "-File",('"' + (Join-Path $PSScriptRoot "Server.ps1") + '"'),"-Port",$port
  ) -WindowStyle Hidden -PassThru
  $ready = $false
  for ($i=0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 250
    try {
      $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port/" -UseBasicParsing -TimeoutSec 1
      if ($r.StatusCode -eq 200) { $ready = $true; break }
    } catch {}
  }
  if (-not $ready) {
    if ($serverProcess) { Stop-Process -Id $serverProcess.Id -Force -ErrorAction SilentlyContinue }
    throw "VirtualRAM Pro could not start its local dashboard server."
  }
}
$url = "http://127.0.0.1:$port/"
$edgeCandidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
)
$chromeCandidates = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$browser = $edgeCandidates + $chromeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($browser) {
  $profile = Join-Path $stateDir "BrowserProfile"
  New-Item -ItemType Directory -Force -Path $profile | Out-Null
  $proc = Start-Process -FilePath $browser -ArgumentList @("--app=$url","--user-data-dir=$profile") -PassThru
  # Dedicated profile keeps this app window separate; stop its local server when the app exits.
  if ($serverProcess) {
    try { Wait-Process -Id $proc.Id -ErrorAction SilentlyContinue } catch {}
    Stop-Process -Id $serverProcess.Id -Force -ErrorAction SilentlyContinue
  }
} else {
  Start-Process $url
  Write-Host "VirtualRAM Pro opened in your default browser. Close this window when finished."
  if ($serverProcess) {
    Read-Host "Press Enter after closing VirtualRAM Pro"
    Stop-Process -Id $serverProcess.Id -Force -ErrorAction SilentlyContinue
  }
}
