param([Parameter(Mandatory=$true)][int]$Port)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$prefix = "http://127.0.0.1:$Port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
$listener.Start()
$stateDir = Join-Path $env:LOCALAPPDATA "VirtualRAMPro"
New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
Set-Content -Path (Join-Path $stateDir "server.pid") -Value $PID
Set-Content -Path (Join-Path $stateDir "server.port") -Value $Port
$mime = @{
  ".html"="text/html; charset=utf-8"; ".js"="application/javascript; charset=utf-8"
  ".json"="application/json; charset=utf-8"; ".webmanifest"="application/manifest+json"
  ".ico"="image/x-icon"; ".png"="image/png"; ".svg"="image/svg+xml"; ".css"="text/css; charset=utf-8"
}
try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $path = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart("/"))
      if ([string]::IsNullOrWhiteSpace($path)) { $path = "index.html" }
      $candidate = [IO.Path]::GetFullPath((Join-Path $root $path))
      $rootFull = [IO.Path]::GetFullPath($root) + [IO.Path]::DirectorySeparatorChar
      if (-not $candidate.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase) -and
          -not $candidate.Equals((Join-Path $root "index.html"), [StringComparison]::OrdinalIgnoreCase)) {
        $ctx.Response.StatusCode = 403
        $bytes = [Text.Encoding]::UTF8.GetBytes("Forbidden")
      } elseif (Test-Path -LiteralPath $candidate -PathType Leaf) {
        $bytes = [IO.File]::ReadAllBytes($candidate)
        $ext = [IO.Path]::GetExtension($candidate).ToLowerInvariant()
        if ($mime.ContainsKey($ext)) { $ctx.Response.ContentType = $mime[$ext] }
        else { $ctx.Response.ContentType = "application/octet-stream" }
        $ctx.Response.StatusCode = 200
      } else {
        $ctx.Response.StatusCode = 404
        $bytes = [Text.Encoding]::UTF8.GetBytes("Not found")
      }
      $ctx.Response.ContentLength64 = $bytes.Length
      $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    } catch {
      try { $ctx.Response.StatusCode = 500; $b=[Text.Encoding]::UTF8.GetBytes("Server error"); $ctx.Response.OutputStream.Write($b,0,$b.Length) } catch {}
    } finally {
      try { $ctx.Response.OutputStream.Close() } catch {}
    }
  }
} finally {
  $listener.Stop()
  $listener.Close()
  Remove-Item (Join-Path $stateDir "server.pid") -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $stateDir "server.port") -ErrorAction SilentlyContinue
}
