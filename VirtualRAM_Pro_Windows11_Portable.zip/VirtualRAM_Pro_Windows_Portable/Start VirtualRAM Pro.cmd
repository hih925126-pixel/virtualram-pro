@echo off
title VirtualRAM Pro Launcher
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0Launch.ps1"
if errorlevel 1 pause
